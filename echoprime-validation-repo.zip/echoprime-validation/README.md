# EchoPrime External Validation Pipeline

External validation of the [EchoPrime](https://www.nature.com/articles/s41586-024-08431-8) echocardiography foundation model on a Greek hospital dataset from the 3rd Cardiology Department of Ippokrateio Hospital, Thessaloniki.

This repository contains the complete data processing, ground truth extraction, and evaluation pipeline developed as part of a research project at the [Information Systems Laboratory](https://islab.uom.gr/), University of Macedonia.

## Project Overview

EchoPrime (Vukadinovic et al., *Nature* 2026) is a vision-language foundation model for comprehensive echocardiogram interpretation, trained primarily on US hospital data (Cedars-Sinai). This project performs an independent, external validation on a European clinical dataset to assess cross-site and cross-vendor generalization.

The pipeline covers:
- **Data organization**: Restructuring raw DICOM and clinical report archives into a standardized layout
- **Ground truth extraction**: Automated NLP-based extraction of clinical labels from Greek echocardiography reports (CHM format)
- **Patient metadata**: Extraction of demographics from DICOM headers and clinical reports, including gender inference for Greeklish names
- **Model evaluation**: Comprehensive evaluation of EchoPrime's predictions against extracted ground truth, covering binary classification tasks, ejection fraction (EF), and right ventricular systolic pressure (RVSP)
- **Embedding analysis**: Per-video embedding extraction and linear probing for LVEF prediction

## Repository Structure

```
echoprime-validation/
│
├── data_pipeline/
│   ├── flatten_dicoms.py              # Reorganize DICOMs into study_id/echo/ structure
│   ├── flatten_reports.py             # Reorganize reports into study_id/report/ structure
│   ├── patient_metadata_extractor.py  # Extract demographics from DICOM + reports
│   └── gender_detection_pipeline.py   # Infer patient gender from Greeklish names
│
├── ground_truth/
│   ├── ground_truth_extractor.py      # Extract binary labels from CHM reports (NLP/regex)
│   └── corpus_explorer_debug.py       # Debug tool for inspecting report corpus coverage
│
├── evaluation/
│   ├── ef_validation_full_dataset.py  # Full EF prediction vs ground truth evaluation
│   ├── ef_threshold_severe_evaluation.py  # Threshold analysis for severe EF dysfunction
│   ├── ef_bin_evaluation_5pct.py      # Binned EF evaluation (5% bins)
│   └── demographics_multicohort_generator.py  # Publication-ready demographics tables
│
├── embeddings/
│   ├── extract_embeddings.py          # Per-video embedding extraction with view classification
│   └── lvef_topview_probing.py        # Ridge regression probing for LVEF from embeddings
│
├── requirements.txt
├── LICENSE
└── README.md
```

## Requirements

- Python 3.8+
- NVIDIA GPU with CUDA support (tested on RTX 3060 12GB)
- [EchoPrime](https://github.com/echonet/echoprime) model repository (cloned separately)
- 7-Zip (for CHM report extraction on Windows)

Install Python dependencies:

```bash
pip install -r requirements.txt
```

## Dataset Layout

The pipeline expects data organized as:

```
<DATASET_DIR>/
├── study_0001/
│   ├── echo/
│   │   ├── file1.dcm
│   │   ├── file2.dcm
│   │   └── ...
│   └── report/
│       └── report.CHM
├── study_0002/
│   ├── echo/
│   └── report/
└── ...
```

Use `flatten_dicoms.py` and `flatten_reports.py` to reorganize raw data into this structure.

## Usage

### 1. Data Organization

```bash
# Reorganize DICOMs (moves files — no extra disk space needed)
python data_pipeline/flatten_dicoms.py --dataset-dir /path/to/data --dry-run
python data_pipeline/flatten_dicoms.py --dataset-dir /path/to/data

# Reorganize reports
python data_pipeline/flatten_reports.py --dataset-dir /path/to/data
```

### 2. Ground Truth Extraction

```bash
# Extract binary labels from clinical reports
python ground_truth/ground_truth_extractor.py --dataset_dir /path/to/data --output labels.csv

# Inspect corpus coverage for specific anatomical sections
python ground_truth/corpus_explorer_debug.py
```

### 3. Patient Metadata & Demographics

```bash
# Extract metadata from DICOM headers and reports
python data_pipeline/patient_metadata_extractor.py

# Infer patient gender from Greeklish names
python data_pipeline/gender_detection_pipeline.py patient_metadata.xlsx

# Generate publication-ready demographics tables
python evaluation/demographics_multicohort_generator.py
```

### 4. Model Evaluation

```bash
# Full EF validation
python evaluation/ef_validation_full_dataset.py

# Severe EF dysfunction threshold analysis
python evaluation/ef_threshold_severe_evaluation.py

# Binned EF evaluation (5% bins)
python evaluation/ef_bin_evaluation_5pct.py
```

### 5. Embedding Extraction & Probing

```bash
# Extract per-video embeddings (GPU required, ~23h for ~2400 studies on RTX 3060)
python embeddings/extract_embeddings.py

# LVEF probing with Ridge regression + bootstrap CIs
python embeddings/lvef_topview_probing.py
```

## Configuration

Each script contains a `CONFIG` block at the top with paths and parameters. Edit these before running:

```python
# Example config block
DATASET_DIR = r"D:\Data Ippokrateio\ORGANIZED_DATA"
GT_CSV      = r"D:\Data Ippokrateio\Evaluation_results_full_dataset\ground_truth.csv"
EXCLUSION   = r"D:\Data Ippokrateio\exclusion_list.txt"
OUTPUT_DIR  = r"D:\Data Ippokrateio\Evaluation_results_full_dataset"
```

## Ground Truth Format

The unified ground truth CSV contains the following columns:

| Column | Description |
|--------|-------------|
| `exam_id` | Unique study identifier |
| `ef_exact` | Exact EF value from report (e.g., `55`) |
| `ef_modifier` | EF with modifier prefix (e.g., `>55`, `~60`) |
| `ef_range` | EF range from report (e.g., `55-60`) |
| `rvsp_exact` | Exact RVSP value (mmHg) |
| `rvsp_modifier` | RVSP with modifier |
| `rvsp_range` | RVSP range |

EF resolution follows a priority chain: `ef_exact` → `ef_range` (mean) → `ef_modifier` (lowest bound).

## Technical Notes

- **CHM Parsing**: Clinical reports are stored as Windows Compiled HTML Help files. The extraction pipeline uses 7-Zip as a subprocess, with fallback to `hh.exe -decompile`. Text encoding is handled dynamically (UTF-8 or Windows-1253).
- **View Classification**: EchoPrime's ConvNeXt-Tiny view classifier runs on CPU; the MViT-v2-S encoder runs on GPU. The embedding extraction script handles device placement accordingly.
- **Checkpointing**: Long-running embedding extraction supports incremental checkpointing (every 50 studies) with atomic writes for safe interruption and resume.
- **Exclusion Lists**: All evaluation scripts support an exclusion list (TXT with one exam_id per line, or CSV) to remove studies with known data quality issues.

## Citation

If you use this code, please cite:

```bibtex
@article{vukadinovic2026echoprime,
  title={Comprehensive echocardiogram evaluation with view primed vision language AI},
  author={Vukadinovic, Milos and others},
  journal={Nature},
  year={2026}
}
```

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.

**Note**: This repository contains evaluation code only. No patient data, DICOM files, or clinical reports are included. The EchoPrime model weights are available separately from the [original repository](https://github.com/echonet/echoprime).
